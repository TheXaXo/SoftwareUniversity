<?php

/* user/profile.html.twig */
class __TwigTemplate_bc92b0c397eb4c99c0372c0ded21a0a67fe56ddc3ced177ead174e4b4c1a0adf extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "user/profile.html.twig", 1);
        $this->blocks = array(
            'body_id' => array($this, 'block_body_id'),
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_02e0c147a67977c235faf147cb88aba9d7832275fbe439637f2c5981590f069e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_02e0c147a67977c235faf147cb88aba9d7832275fbe439637f2c5981590f069e->enter($__internal_02e0c147a67977c235faf147cb88aba9d7832275fbe439637f2c5981590f069e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "user/profile.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_02e0c147a67977c235faf147cb88aba9d7832275fbe439637f2c5981590f069e->leave($__internal_02e0c147a67977c235faf147cb88aba9d7832275fbe439637f2c5981590f069e_prof);

    }

    // line 3
    public function block_body_id($context, array $blocks = array())
    {
        $__internal_ef24139cf03d48d65dad6f3a02d77d67c8bb3b7893a06df03cac432e231579ba = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ef24139cf03d48d65dad6f3a02d77d67c8bb3b7893a06df03cac432e231579ba->enter($__internal_ef24139cf03d48d65dad6f3a02d77d67c8bb3b7893a06df03cac432e231579ba_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        echo "profile";
        
        $__internal_ef24139cf03d48d65dad6f3a02d77d67c8bb3b7893a06df03cac432e231579ba->leave($__internal_ef24139cf03d48d65dad6f3a02d77d67c8bb3b7893a06df03cac432e231579ba_prof);

    }

    // line 5
    public function block_main($context, array $blocks = array())
    {
        $__internal_501a9f6c2f7bc9f6e7db4f9db9f74c1b0c1ffca2361d5c7603e09f6416bda1d3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_501a9f6c2f7bc9f6e7db4f9db9f74c1b0c1ffca2361d5c7603e09f6416bda1d3->enter($__internal_501a9f6c2f7bc9f6e7db4f9db9f74c1b0c1ffca2361d5c7603e09f6416bda1d3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 6
        echo "    <div>
        ";
        // line 7
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "email", array()), "html", null, true);
        echo "
        <br>
        ";
        // line 9
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "fullName", array()), "html", null, true);
        echo "
    </div>
";
        
        $__internal_501a9f6c2f7bc9f6e7db4f9db9f74c1b0c1ffca2361d5c7603e09f6416bda1d3->leave($__internal_501a9f6c2f7bc9f6e7db4f9db9f74c1b0c1ffca2361d5c7603e09f6416bda1d3_prof);

    }

    public function getTemplateName()
    {
        return "user/profile.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  61 => 9,  56 => 7,  53 => 6,  47 => 5,  35 => 3,  11 => 1,);
    }

    public function getSource()
    {
        return "{% extends 'base.html.twig' %}

{% block body_id 'profile' %}

{% block main %}
    <div>
        {{ user.email }}
        <br>
        {{ user.fullName }}
    </div>
{% endblock %}
";
    }
}
