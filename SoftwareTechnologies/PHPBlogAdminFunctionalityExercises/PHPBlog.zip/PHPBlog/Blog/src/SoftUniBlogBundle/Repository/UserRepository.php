<?php

namespace SoftUniBlogBundle\Repository;


class UserRepository extends \Doctrine\ORM\EntityRepository
{
}
