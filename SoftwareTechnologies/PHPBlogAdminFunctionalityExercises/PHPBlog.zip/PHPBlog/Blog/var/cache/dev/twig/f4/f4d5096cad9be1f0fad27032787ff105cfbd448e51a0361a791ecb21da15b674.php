<?php

/* @Framework/Form/choice_options.html.php */
class __TwigTemplate_831a409abe3d9c2f3a2e0d08c88c3da5abf5df7bb1ca420da86aa077e3bf1980 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5f1421ef26bac1523e827a573b4cff8ee46240470738dec9319faf2459844518 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5f1421ef26bac1523e827a573b4cff8ee46240470738dec9319faf2459844518->enter($__internal_5f1421ef26bac1523e827a573b4cff8ee46240470738dec9319faf2459844518_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_options.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'choice_widget_options') ?>
";
        
        $__internal_5f1421ef26bac1523e827a573b4cff8ee46240470738dec9319faf2459844518->leave($__internal_5f1421ef26bac1523e827a573b4cff8ee46240470738dec9319faf2459844518_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/choice_options.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSource()
    {
        return "<?php echo \$view['form']->block(\$form, 'choice_widget_options') ?>
";
    }
}
