<?php

/* base.html.twig */
class __TwigTemplate_0a141e81b29aa4b3246f3b90067d315bfea51bc528ed95094efa7f48bac77222 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body_id' => array($this, 'block_body_id'),
            'header' => array($this, 'block_header'),
            'body' => array($this, 'block_body'),
            'main' => array($this, 'block_main'),
            'footer' => array($this, 'block_footer'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_750c4d0fa829097ab913c9a3f71e72f90197e86339957d81302a3111cb2cbf74 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_750c4d0fa829097ab913c9a3f71e72f90197e86339957d81302a3111cb2cbf74->enter($__internal_750c4d0fa829097ab913c9a3f71e72f90197e86339957d81302a3111cb2cbf74_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 6
        echo "<!DOCTYPE html>
<html lang=\"en-US\">
<head>
    <meta charset=\"UTF-8\"/>
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"/>
    <title>";
        // line 11
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
    ";
        // line 12
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 16
        echo "    <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\"/>
</head>

<body id=\"";
        // line 19
        $this->displayBlock('body_id', $context, $blocks);
        echo "\">

";
        // line 21
        $this->displayBlock('header', $context, $blocks);
        // line 75
        echo "
<div class=\"container body-container\">
    ";
        // line 77
        $this->displayBlock('body', $context, $blocks);
        // line 86
        echo "</div>

";
        // line 88
        $this->displayBlock('footer', $context, $blocks);
        // line 95
        echo "
";
        // line 96
        $this->displayBlock('javascripts', $context, $blocks);
        // line 102
        echo "
</body>
</html>
";
        
        $__internal_750c4d0fa829097ab913c9a3f71e72f90197e86339957d81302a3111cb2cbf74->leave($__internal_750c4d0fa829097ab913c9a3f71e72f90197e86339957d81302a3111cb2cbf74_prof);

    }

    // line 11
    public function block_title($context, array $blocks = array())
    {
        $__internal_e6310d1ecfbd43c822f52cbd3202d9325828c47fcb2d683f68ed836d870f9b22 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e6310d1ecfbd43c822f52cbd3202d9325828c47fcb2d683f68ed836d870f9b22->enter($__internal_e6310d1ecfbd43c822f52cbd3202d9325828c47fcb2d683f68ed836d870f9b22_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "SoftUni Blog";
        
        $__internal_e6310d1ecfbd43c822f52cbd3202d9325828c47fcb2d683f68ed836d870f9b22->leave($__internal_e6310d1ecfbd43c822f52cbd3202d9325828c47fcb2d683f68ed836d870f9b22_prof);

    }

    // line 12
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_33c914ad627a668a11c16cdae14dbcbf13fc461e75332f26842ddb77ce5849f1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_33c914ad627a668a11c16cdae14dbcbf13fc461e75332f26842ddb77ce5849f1->enter($__internal_33c914ad627a668a11c16cdae14dbcbf13fc461e75332f26842ddb77ce5849f1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 13
        echo "        <link rel=\"stylesheet\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/style.css"), "html", null, true);
        echo "\">
        <link rel=\"stylesheet\" href=\"";
        // line 14
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/bootstrap-datetimepicker.min.css"), "html", null, true);
        echo "\">
    ";
        
        $__internal_33c914ad627a668a11c16cdae14dbcbf13fc461e75332f26842ddb77ce5849f1->leave($__internal_33c914ad627a668a11c16cdae14dbcbf13fc461e75332f26842ddb77ce5849f1_prof);

    }

    // line 19
    public function block_body_id($context, array $blocks = array())
    {
        $__internal_27692adab6f6f57b9f6d0a64e9a52cfa286eca44a1a67b9781635bb3b794bc0b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_27692adab6f6f57b9f6d0a64e9a52cfa286eca44a1a67b9781635bb3b794bc0b->enter($__internal_27692adab6f6f57b9f6d0a64e9a52cfa286eca44a1a67b9781635bb3b794bc0b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        
        $__internal_27692adab6f6f57b9f6d0a64e9a52cfa286eca44a1a67b9781635bb3b794bc0b->leave($__internal_27692adab6f6f57b9f6d0a64e9a52cfa286eca44a1a67b9781635bb3b794bc0b_prof);

    }

    // line 21
    public function block_header($context, array $blocks = array())
    {
        $__internal_3cac07558d6181ddbb97c8f1d27228cd112a5d8c0f35511762db2c0a804ecadc = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3cac07558d6181ddbb97c8f1d27228cd112a5d8c0f35511762db2c0a804ecadc->enter($__internal_3cac07558d6181ddbb97c8f1d27228cd112a5d8c0f35511762db2c0a804ecadc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header"));

        // line 22
        echo "    <header>
        <div class=\"navbar navbar-default navbar-static-top\" role=\"navigation\">
            <div class=\"container\">
                <div class=\"navbar-header\">
                    <a href=\"";
        // line 26
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("blog_index");
        echo "\" class=\"navbar-brand\">SOFTUNI BLOG</a>

                    <button type=\"button\" class=\"navbar-toggle\" data-toggle=\"collapse\" data-target=\".navbar-collapse\">
                        <span class=\"icon-bar\"></span>
                        <span class=\"icon-bar\"></span>
                        <span class=\"icon-bar\"></span>
                    </button>
                </div>
                <div class=\"navbar-collapse collapse\">
                    <ul class=\"nav navbar-nav navbar-right\">
                        ";
        // line 36
        if ($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array())) {
            // line 37
            echo "                            ";
            if ($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "getUser", array(), "method"), "isAdmin", array())) {
                // line 38
                echo "                                <li>
                                    <a>Admin</a>
                                </li>
                            ";
            }
            // line 42
            echo "                            <li>
                                <a href=\"";
            // line 43
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("article_create");
            echo "\">
                                    Create Article
                                </a>
                            </li>
                            <li>
                                <a href=\"";
            // line 48
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("user_profile");
            echo "\">
                                    My Profile
                                </a>
                            </li>
                            <li>
                                <a href=\"";
            // line 53
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("security_logout");
            echo "\">
                                    Logout
                                </a>
                            </li>
                        ";
        } else {
            // line 58
            echo "                            <li>
                                <a href=\"";
            // line 59
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("user_register");
            echo "\">
                                    REGISTER
                                </a>
                            </li>
                            <li>
                                <a href=\"";
            // line 64
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("security_login");
            echo "\">
                                    LOGIN
                                </a>
                            </li>
                        ";
        }
        // line 69
        echo "                    </ul>
                </div>
            </div>
        </div>
    </header>
";
        
        $__internal_3cac07558d6181ddbb97c8f1d27228cd112a5d8c0f35511762db2c0a804ecadc->leave($__internal_3cac07558d6181ddbb97c8f1d27228cd112a5d8c0f35511762db2c0a804ecadc_prof);

    }

    // line 77
    public function block_body($context, array $blocks = array())
    {
        $__internal_6c1652bb10e259b9839c30a964bb9b09c0fe6bbb45ded53341ff9034329b4c8d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6c1652bb10e259b9839c30a964bb9b09c0fe6bbb45ded53341ff9034329b4c8d->enter($__internal_6c1652bb10e259b9839c30a964bb9b09c0fe6bbb45ded53341ff9034329b4c8d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 78
        echo "        <div class=\"row\">
            <div id=\"main\" class=\"col-sm-9\">
                ";
        // line 80
        $this->displayBlock('main', $context, $blocks);
        // line 83
        echo "            </div>
        </div>
    ";
        
        $__internal_6c1652bb10e259b9839c30a964bb9b09c0fe6bbb45ded53341ff9034329b4c8d->leave($__internal_6c1652bb10e259b9839c30a964bb9b09c0fe6bbb45ded53341ff9034329b4c8d_prof);

    }

    // line 80
    public function block_main($context, array $blocks = array())
    {
        $__internal_8ab40b40a0a1ad48f75140a31b8de3706763406fba00e5edb5565fd2ed6c5d59 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8ab40b40a0a1ad48f75140a31b8de3706763406fba00e5edb5565fd2ed6c5d59->enter($__internal_8ab40b40a0a1ad48f75140a31b8de3706763406fba00e5edb5565fd2ed6c5d59_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 81
        echo "
                ";
        
        $__internal_8ab40b40a0a1ad48f75140a31b8de3706763406fba00e5edb5565fd2ed6c5d59->leave($__internal_8ab40b40a0a1ad48f75140a31b8de3706763406fba00e5edb5565fd2ed6c5d59_prof);

    }

    // line 88
    public function block_footer($context, array $blocks = array())
    {
        $__internal_38e82f37981fc6a34d4a6b01fadd3955de9e9f6e9d80be47dc9f88702bd7268d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_38e82f37981fc6a34d4a6b01fadd3955de9e9f6e9d80be47dc9f88702bd7268d->enter($__internal_38e82f37981fc6a34d4a6b01fadd3955de9e9f6e9d80be47dc9f88702bd7268d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "footer"));

        // line 89
        echo "    <footer>
        <div class=\"container modal-footer\">
            <p>&copy; 2016 - Software University Foundation</p>
        </div>
    </footer>
";
        
        $__internal_38e82f37981fc6a34d4a6b01fadd3955de9e9f6e9d80be47dc9f88702bd7268d->leave($__internal_38e82f37981fc6a34d4a6b01fadd3955de9e9f6e9d80be47dc9f88702bd7268d_prof);

    }

    // line 96
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_d08a39a8d6a52609d4794483488b0f0fd5ea1d8bdb02298f1a7b898d826b983b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d08a39a8d6a52609d4794483488b0f0fd5ea1d8bdb02298f1a7b898d826b983b->enter($__internal_d08a39a8d6a52609d4794483488b0f0fd5ea1d8bdb02298f1a7b898d826b983b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 97
        echo "    <script src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/jquery-2.2.4.min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 98
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/moment.min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 99
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/bootstrap.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 100
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/bootstrap-datetimepicker.min.js"), "html", null, true);
        echo "\"></script>
";
        
        $__internal_d08a39a8d6a52609d4794483488b0f0fd5ea1d8bdb02298f1a7b898d826b983b->leave($__internal_d08a39a8d6a52609d4794483488b0f0fd5ea1d8bdb02298f1a7b898d826b983b_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  293 => 100,  289 => 99,  285 => 98,  280 => 97,  274 => 96,  262 => 89,  256 => 88,  248 => 81,  242 => 80,  233 => 83,  231 => 80,  227 => 78,  221 => 77,  209 => 69,  201 => 64,  193 => 59,  190 => 58,  182 => 53,  174 => 48,  166 => 43,  163 => 42,  157 => 38,  154 => 37,  152 => 36,  139 => 26,  133 => 22,  127 => 21,  116 => 19,  107 => 14,  102 => 13,  96 => 12,  84 => 11,  74 => 102,  72 => 96,  69 => 95,  67 => 88,  63 => 86,  61 => 77,  57 => 75,  55 => 21,  50 => 19,  43 => 16,  41 => 12,  37 => 11,  30 => 6,);
    }

    public function getSource()
    {
        return "{#
   This is the base template used as the application layout which contains the
   common elements and decorates all the other templates.
   See http://symfony.com/doc/current/book/templating.html#template-inheritance-and-layouts
#}
<!DOCTYPE html>
<html lang=\"en-US\">
<head>
    <meta charset=\"UTF-8\"/>
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"/>
    <title>{% block title %}SoftUni Blog{% endblock %}</title>
    {% block stylesheets %}
        <link rel=\"stylesheet\" href=\"{{ asset('css/style.css') }}\">
        <link rel=\"stylesheet\" href=\"{{ asset('css/bootstrap-datetimepicker.min.css') }}\">
    {% endblock %}
    <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('favicon.ico') }}\"/>
</head>

<body id=\"{% block body_id %}{% endblock %}\">

{% block header %}
    <header>
        <div class=\"navbar navbar-default navbar-static-top\" role=\"navigation\">
            <div class=\"container\">
                <div class=\"navbar-header\">
                    <a href=\"{{ path('blog_index') }}\" class=\"navbar-brand\">SOFTUNI BLOG</a>

                    <button type=\"button\" class=\"navbar-toggle\" data-toggle=\"collapse\" data-target=\".navbar-collapse\">
                        <span class=\"icon-bar\"></span>
                        <span class=\"icon-bar\"></span>
                        <span class=\"icon-bar\"></span>
                    </button>
                </div>
                <div class=\"navbar-collapse collapse\">
                    <ul class=\"nav navbar-nav navbar-right\">
                        {% if app.user %}
                            {% if app.getUser().isAdmin %}
                                <li>
                                    <a>Admin</a>
                                </li>
                            {% endif %}
                            <li>
                                <a href=\"{{ path('article_create') }}\">
                                    Create Article
                                </a>
                            </li>
                            <li>
                                <a href=\"{{ path('user_profile') }}\">
                                    My Profile
                                </a>
                            </li>
                            <li>
                                <a href=\"{{ path('security_logout') }}\">
                                    Logout
                                </a>
                            </li>
                        {% else %}
                            <li>
                                <a href=\"{{ path('user_register') }}\">
                                    REGISTER
                                </a>
                            </li>
                            <li>
                                <a href=\"{{ path('security_login') }}\">
                                    LOGIN
                                </a>
                            </li>
                        {% endif %}
                    </ul>
                </div>
            </div>
        </div>
    </header>
{% endblock %}

<div class=\"container body-container\">
    {% block body %}
        <div class=\"row\">
            <div id=\"main\" class=\"col-sm-9\">
                {% block main %}

                {% endblock %}
            </div>
        </div>
    {% endblock %}
</div>

{% block footer %}
    <footer>
        <div class=\"container modal-footer\">
            <p>&copy; 2016 - Software University Foundation</p>
        </div>
    </footer>
{% endblock %}

{% block javascripts %}
    <script src=\"{{ asset('js/jquery-2.2.4.min.js') }}\"></script>
    <script src=\"{{ asset('js/moment.min.js') }}\"></script>
    <script src=\"{{ asset('js/bootstrap.js') }}\"></script>
    <script src=\"{{ asset('js/bootstrap-datetimepicker.min.js') }}\"></script>
{% endblock %}

</body>
</html>
";
    }
}
