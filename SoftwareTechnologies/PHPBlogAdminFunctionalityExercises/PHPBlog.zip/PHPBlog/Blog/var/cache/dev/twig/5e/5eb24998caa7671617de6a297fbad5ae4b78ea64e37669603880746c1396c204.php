<?php

/* @Twig/Exception/exception_full.html.twig */
class __TwigTemplate_72c0198a59b8702a03bf9b3b4578008df34d6ca2f20b6cc80c86dae1633d3901 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@Twig/layout.html.twig", "@Twig/Exception/exception_full.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@Twig/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c7b147dad7b55f905c20d4c18298ab72e332416165390da655f20aa7f921cf77 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c7b147dad7b55f905c20d4c18298ab72e332416165390da655f20aa7f921cf77->enter($__internal_c7b147dad7b55f905c20d4c18298ab72e332416165390da655f20aa7f921cf77_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception_full.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_c7b147dad7b55f905c20d4c18298ab72e332416165390da655f20aa7f921cf77->leave($__internal_c7b147dad7b55f905c20d4c18298ab72e332416165390da655f20aa7f921cf77_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_3e18dc59d0c41ea9cd1c1c3b92326295c1f2f5370df4f2c16b74a9a23f967db8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3e18dc59d0c41ea9cd1c1c3b92326295c1f2f5370df4f2c16b74a9a23f967db8->enter($__internal_3e18dc59d0c41ea9cd1c1c3b92326295c1f2f5370df4f2c16b74a9a23f967db8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    <link href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\HttpFoundationExtension')->generateAbsoluteUrl($this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/framework/css/exception.css")), "html", null, true);
        echo "\" rel=\"stylesheet\" type=\"text/css\" media=\"all\" />
";
        
        $__internal_3e18dc59d0c41ea9cd1c1c3b92326295c1f2f5370df4f2c16b74a9a23f967db8->leave($__internal_3e18dc59d0c41ea9cd1c1c3b92326295c1f2f5370df4f2c16b74a9a23f967db8_prof);

    }

    // line 7
    public function block_title($context, array $blocks = array())
    {
        $__internal_5fe5374f2fa2e50368c0eed5c2028d0852b2f670789c6501becdf1647d695797 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5fe5374f2fa2e50368c0eed5c2028d0852b2f670789c6501becdf1647d695797->enter($__internal_5fe5374f2fa2e50368c0eed5c2028d0852b2f670789c6501becdf1647d695797_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 8
        echo "    ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")), "message", array()), "html", null, true);
        echo " (";
        echo twig_escape_filter($this->env, (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code")), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, (isset($context["status_text"]) ? $context["status_text"] : $this->getContext($context, "status_text")), "html", null, true);
        echo ")
";
        
        $__internal_5fe5374f2fa2e50368c0eed5c2028d0852b2f670789c6501becdf1647d695797->leave($__internal_5fe5374f2fa2e50368c0eed5c2028d0852b2f670789c6501becdf1647d695797_prof);

    }

    // line 11
    public function block_body($context, array $blocks = array())
    {
        $__internal_72aed95d3ffb1bd809769c8b4a20bc0cf2c95364cd94ab3d6c3e967b05e711d3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_72aed95d3ffb1bd809769c8b4a20bc0cf2c95364cd94ab3d6c3e967b05e711d3->enter($__internal_72aed95d3ffb1bd809769c8b4a20bc0cf2c95364cd94ab3d6c3e967b05e711d3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 12
        echo "    ";
        $this->loadTemplate("@Twig/Exception/exception.html.twig", "@Twig/Exception/exception_full.html.twig", 12)->display($context);
        
        $__internal_72aed95d3ffb1bd809769c8b4a20bc0cf2c95364cd94ab3d6c3e967b05e711d3->leave($__internal_72aed95d3ffb1bd809769c8b4a20bc0cf2c95364cd94ab3d6c3e967b05e711d3_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/exception_full.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  78 => 12,  72 => 11,  58 => 8,  52 => 7,  42 => 4,  36 => 3,  11 => 1,);
    }

    public function getSource()
    {
        return "{% extends '@Twig/layout.html.twig' %}

{% block head %}
    <link href=\"{{ absolute_url(asset('bundles/framework/css/exception.css')) }}\" rel=\"stylesheet\" type=\"text/css\" media=\"all\" />
{% endblock %}

{% block title %}
    {{ exception.message }} ({{ status_code }} {{ status_text }})
{% endblock %}

{% block body %}
    {% include '@Twig/Exception/exception.html.twig' %}
{% endblock %}
";
    }
}
