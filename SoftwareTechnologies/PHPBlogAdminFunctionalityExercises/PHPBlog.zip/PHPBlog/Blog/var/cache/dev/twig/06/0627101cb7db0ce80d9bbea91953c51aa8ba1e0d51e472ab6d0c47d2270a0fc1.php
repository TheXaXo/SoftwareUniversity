<?php

/* article/article.html.twig */
class __TwigTemplate_bebaa9e128af523ecf1c0de13c8eed0d793d8faf8d6f963ea7ffe1db638ab812 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "article/article.html.twig", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3dd015911d1f796fe667b97d6532c862795e67e59999fc79aa54fdd44230731a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3dd015911d1f796fe667b97d6532c862795e67e59999fc79aa54fdd44230731a->enter($__internal_3dd015911d1f796fe667b97d6532c862795e67e59999fc79aa54fdd44230731a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "article/article.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_3dd015911d1f796fe667b97d6532c862795e67e59999fc79aa54fdd44230731a->leave($__internal_3dd015911d1f796fe667b97d6532c862795e67e59999fc79aa54fdd44230731a_prof);

    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        $__internal_fc311f235b8cc4964c3fda448c10f712c73167cdd413c1267365c28b45347c95 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fc311f235b8cc4964c3fda448c10f712c73167cdd413c1267365c28b45347c95->enter($__internal_fc311f235b8cc4964c3fda448c10f712c73167cdd413c1267365c28b45347c95_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 4
        echo "    <div class=\"container body-content\">
        <div class=\"row\">
            <div class=\"col-md-12\">
                <article>
                    <header>
                        <h2>";
        // line 9
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["article"]) ? $context["article"] : $this->getContext($context, "article")), "title", array()), "html", null, true);
        echo "</h2>
                    </header>

                    <p>
                        ";
        // line 13
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["article"]) ? $context["article"] : $this->getContext($context, "article")), "content", array()), "html", null, true);
        echo "
                    </p>

                    <small class=\"author\">
                        ";
        // line 17
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["article"]) ? $context["article"] : $this->getContext($context, "article")), "author", array()), "html", null, true);
        echo "
                    </small>

                    <footer>
                        <div class=\"pull-right\">
                            <a class=\"btn btn-default btn-xs\" href=\"";
        // line 22
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("blog_index");
        echo "\">&laquo; Back</a>
                        </div>
                    </footer>
                </article>
            </div>
        </div>
    </div>

";
        
        $__internal_fc311f235b8cc4964c3fda448c10f712c73167cdd413c1267365c28b45347c95->leave($__internal_fc311f235b8cc4964c3fda448c10f712c73167cdd413c1267365c28b45347c95_prof);

    }

    public function getTemplateName()
    {
        return "article/article.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  69 => 22,  61 => 17,  54 => 13,  47 => 9,  40 => 4,  34 => 3,  11 => 1,);
    }

    public function getSource()
    {
        return "{% extends 'base.html.twig' %}

{% block main %}
    <div class=\"container body-content\">
        <div class=\"row\">
            <div class=\"col-md-12\">
                <article>
                    <header>
                        <h2>{{ article.title }}</h2>
                    </header>

                    <p>
                        {{ article.content }}
                    </p>

                    <small class=\"author\">
                        {{ article.author }}
                    </small>

                    <footer>
                        <div class=\"pull-right\">
                            <a class=\"btn btn-default btn-xs\" href=\"{{ path('blog_index') }}\">&laquo; Back</a>
                        </div>
                    </footer>
                </article>
            </div>
        </div>
    </div>

{% endblock %}

";
    }
}
