<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_82224528254c6c482ba188a9b3870fc82cf2d6e6bd25a3f960301a4746dac8b9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f834b59a28b0936cbf04f793e914a54d5dcdb7d7f015b8d2b0f3d431b5257240 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f834b59a28b0936cbf04f793e914a54d5dcdb7d7f015b8d2b0f3d431b5257240->enter($__internal_f834b59a28b0936cbf04f793e914a54d5dcdb7d7f015b8d2b0f3d431b5257240_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_f834b59a28b0936cbf04f793e914a54d5dcdb7d7f015b8d2b0f3d431b5257240->leave($__internal_f834b59a28b0936cbf04f793e914a54d5dcdb7d7f015b8d2b0f3d431b5257240_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_505c72992cec9220e20d88e9182fda771a67d6d090a91223e487d60d802768d5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_505c72992cec9220e20d88e9182fda771a67d6d090a91223e487d60d802768d5->enter($__internal_505c72992cec9220e20d88e9182fda771a67d6d090a91223e487d60d802768d5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_505c72992cec9220e20d88e9182fda771a67d6d090a91223e487d60d802768d5->leave($__internal_505c72992cec9220e20d88e9182fda771a67d6d090a91223e487d60d802768d5_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_350f06d161b41be1b1b7aa1ebd98df1ace241c02254d76c87ba14b374a3a1e99 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_350f06d161b41be1b1b7aa1ebd98df1ace241c02254d76c87ba14b374a3a1e99->enter($__internal_350f06d161b41be1b1b7aa1ebd98df1ace241c02254d76c87ba14b374a3a1e99_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_350f06d161b41be1b1b7aa1ebd98df1ace241c02254d76c87ba14b374a3a1e99->leave($__internal_350f06d161b41be1b1b7aa1ebd98df1ace241c02254d76c87ba14b374a3a1e99_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_97f5cb2f50fbade73de303048ccd7d1ec21c82599d1c73770e51be44559b1623 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_97f5cb2f50fbade73de303048ccd7d1ec21c82599d1c73770e51be44559b1623->enter($__internal_97f5cb2f50fbade73de303048ccd7d1ec21c82599d1c73770e51be44559b1623_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\HttpKernelExtension')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_97f5cb2f50fbade73de303048ccd7d1ec21c82599d1c73770e51be44559b1623->leave($__internal_97f5cb2f50fbade73de303048ccd7d1ec21c82599d1c73770e51be44559b1623_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  73 => 13,  67 => 12,  56 => 7,  53 => 6,  47 => 5,  36 => 3,  11 => 1,);
    }

    public function getSource()
    {
        return "{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
";
    }
}
