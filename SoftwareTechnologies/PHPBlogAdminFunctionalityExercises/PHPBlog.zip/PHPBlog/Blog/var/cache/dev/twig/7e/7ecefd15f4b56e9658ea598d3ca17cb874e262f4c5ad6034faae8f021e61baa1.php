<?php

/* user/profile.html.twig */
class __TwigTemplate_24c1295b428e071853a49eec92f8d345f25acd0cb3f6daf2ef44ec462c03d15e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "user/profile.html.twig", 1);
        $this->blocks = array(
            'body_id' => array($this, 'block_body_id'),
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f1c61c9db57b2902c6df19241392e868e8be5fd00d51a13cd30896e690575007 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f1c61c9db57b2902c6df19241392e868e8be5fd00d51a13cd30896e690575007->enter($__internal_f1c61c9db57b2902c6df19241392e868e8be5fd00d51a13cd30896e690575007_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "user/profile.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_f1c61c9db57b2902c6df19241392e868e8be5fd00d51a13cd30896e690575007->leave($__internal_f1c61c9db57b2902c6df19241392e868e8be5fd00d51a13cd30896e690575007_prof);

    }

    // line 3
    public function block_body_id($context, array $blocks = array())
    {
        $__internal_90d02c7483060569c5bb98c042b18760fb70d1427ca259262d4472eefd75e9f8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_90d02c7483060569c5bb98c042b18760fb70d1427ca259262d4472eefd75e9f8->enter($__internal_90d02c7483060569c5bb98c042b18760fb70d1427ca259262d4472eefd75e9f8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        echo "profile";
        
        $__internal_90d02c7483060569c5bb98c042b18760fb70d1427ca259262d4472eefd75e9f8->leave($__internal_90d02c7483060569c5bb98c042b18760fb70d1427ca259262d4472eefd75e9f8_prof);

    }

    // line 5
    public function block_main($context, array $blocks = array())
    {
        $__internal_ecac3615cdd52bf4624ce1b9eff3539aa5f6ffaacf1cfe1ecca9d712f9cd75ee = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ecac3615cdd52bf4624ce1b9eff3539aa5f6ffaacf1cfe1ecca9d712f9cd75ee->enter($__internal_ecac3615cdd52bf4624ce1b9eff3539aa5f6ffaacf1cfe1ecca9d712f9cd75ee_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 6
        echo "    <div>
        ";
        // line 7
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "email", array()), "html", null, true);
        echo "
        <br>
        ";
        // line 9
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "fullName", array()), "html", null, true);
        echo "
    </div>
";
        
        $__internal_ecac3615cdd52bf4624ce1b9eff3539aa5f6ffaacf1cfe1ecca9d712f9cd75ee->leave($__internal_ecac3615cdd52bf4624ce1b9eff3539aa5f6ffaacf1cfe1ecca9d712f9cd75ee_prof);

    }

    public function getTemplateName()
    {
        return "user/profile.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  61 => 9,  56 => 7,  53 => 6,  47 => 5,  35 => 3,  11 => 1,);
    }

    public function getSource()
    {
        return "{% extends 'base.html.twig' %}

{% block body_id 'profile' %}

{% block main %}
    <div>
        {{ user.email }}
        <br>
        {{ user.fullName }}
    </div>
{% endblock %}
";
    }
}
