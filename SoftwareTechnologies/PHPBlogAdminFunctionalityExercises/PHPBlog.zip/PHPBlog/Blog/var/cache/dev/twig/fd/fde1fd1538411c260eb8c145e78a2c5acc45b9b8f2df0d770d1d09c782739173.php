<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_259a856f809a3490c132184b60d9b5a5591eb7f49b2cb74ae2110991015e8186 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_044f87dae62adcdee037c1ae8d65879f61599a5012d187386993d0dfc62a3b7f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_044f87dae62adcdee037c1ae8d65879f61599a5012d187386993d0dfc62a3b7f->enter($__internal_044f87dae62adcdee037c1ae8d65879f61599a5012d187386993d0dfc62a3b7f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_044f87dae62adcdee037c1ae8d65879f61599a5012d187386993d0dfc62a3b7f->leave($__internal_044f87dae62adcdee037c1ae8d65879f61599a5012d187386993d0dfc62a3b7f_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_e0ad350335d16a96ec81cdfce726c92a4f6fd6597b32cc45764d7b505fa8656e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e0ad350335d16a96ec81cdfce726c92a4f6fd6597b32cc45764d7b505fa8656e->enter($__internal_e0ad350335d16a96ec81cdfce726c92a4f6fd6597b32cc45764d7b505fa8656e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_e0ad350335d16a96ec81cdfce726c92a4f6fd6597b32cc45764d7b505fa8656e->leave($__internal_e0ad350335d16a96ec81cdfce726c92a4f6fd6597b32cc45764d7b505fa8656e_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_7dcf5555e0e9b4a6b35a8f468323c45479193d1d0c5d9bf8662082293f54362f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7dcf5555e0e9b4a6b35a8f468323c45479193d1d0c5d9bf8662082293f54362f->enter($__internal_7dcf5555e0e9b4a6b35a8f468323c45479193d1d0c5d9bf8662082293f54362f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_7dcf5555e0e9b4a6b35a8f468323c45479193d1d0c5d9bf8662082293f54362f->leave($__internal_7dcf5555e0e9b4a6b35a8f468323c45479193d1d0c5d9bf8662082293f54362f_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_a5ca07bd35c0922c5d63146998708a3e4058bcb03a59dec536c6ec35d0ef5bee = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a5ca07bd35c0922c5d63146998708a3e4058bcb03a59dec536c6ec35d0ef5bee->enter($__internal_a5ca07bd35c0922c5d63146998708a3e4058bcb03a59dec536c6ec35d0ef5bee_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\HttpKernelExtension')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_a5ca07bd35c0922c5d63146998708a3e4058bcb03a59dec536c6ec35d0ef5bee->leave($__internal_a5ca07bd35c0922c5d63146998708a3e4058bcb03a59dec536c6ec35d0ef5bee_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  73 => 13,  67 => 12,  56 => 7,  53 => 6,  47 => 5,  36 => 3,  11 => 1,);
    }

    public function getSource()
    {
        return "{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
";
    }
}
