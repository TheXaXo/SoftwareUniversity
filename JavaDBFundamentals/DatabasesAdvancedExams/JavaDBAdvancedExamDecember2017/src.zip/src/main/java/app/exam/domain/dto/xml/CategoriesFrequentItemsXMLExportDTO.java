package app.exam.domain.dto.xml;

public class CategoriesFrequentItemsXMLExportDTO {

}
