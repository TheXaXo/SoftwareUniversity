package app.exam.io.interfaces;

public interface ConsoleIO {
    void write(String line);
}
