package CatLady;

public class StreetExtraordinareCat extends Cat {
    private double decibelsOfMeow;

    public StreetExtraordinareCat(String name, double decibelsOfMeow) {
        this.setName(name);
        this.decibelsOfMeow = decibelsOfMeow;
    }

    @Override
    public String toString() {
        return "StreetExtraordinaire " + this.getName() + " " + this.decibelsOfMeow;
    }
}
